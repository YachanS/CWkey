Stripe integration for Nyl2Pronos

Last release downloaded here : https://github.com/stripe/stripe-php/releases