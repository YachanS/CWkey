Please only file issues here that you believe represent actual bugs or feature requests for the Stripe PHP library.

If you're having general trouble with your Stripe integration, please reach out to support using the form at https://support.stripe.com/ (preferred) or via email to support@stripe.com.

If you are reporting a bug, please include your PHP version and the version of the Stripe PHP library you're using, as well as any other details that may be helpful in reproducing the problem.
